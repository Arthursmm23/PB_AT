package org.example.model;

public class Administrador extends Usuario {
    public void gerenciarUsuarios() {
        System.out.println("Gerenciando usuários...");
    }

    public void gerarRelatorios() {
        System.out.println("Relatórios gerados.");
    }
}
