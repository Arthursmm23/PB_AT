package org.example.service;

import org.example.model.Manutencao;
import org.example.model.Veiculo;
import org.example.repository.ManutencaoRepository;
import org.example.repository.VeiculoRepository;
import org.example.model.EmailUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class VeiculoService {

    private final VeiculoRepository veiculoRepository;
    private final ManutencaoRepository manutencaoRepository;
    private final EmailUtil emailUtil;

    @Autowired
    public VeiculoService(VeiculoRepository veiculoRepository,
                          ManutencaoRepository manutencaoRepository,
                          EmailUtil emailUtil) {
        this.veiculoRepository = veiculoRepository;
        this.manutencaoRepository = manutencaoRepository;
        this.emailUtil = emailUtil;
    }

    public Page<Veiculo> listarTodos(Pageable pageable) {
        return veiculoRepository.findAll(pageable);
    }

    public Veiculo salvar(Veiculo veiculo) {
        return veiculoRepository.save(veiculo);
    }

    public Veiculo atualizar(String placa, Veiculo veiculoAtualizado) {
        Optional<Veiculo> veiculoOptional = veiculoRepository.findById(placa);
        if (veiculoOptional.isEmpty()) {
            throw new RuntimeException("Veículo não encontrado");
        }

        Veiculo veiculoExistente = veiculoOptional.get();
        veiculoExistente.setModelo(veiculoAtualizado.getModelo());
        veiculoExistente.setTipo(veiculoAtualizado.getTipo());
        veiculoExistente.setAno(veiculoAtualizado.getAno());
        veiculoExistente.setQuilometragemAtual(veiculoAtualizado.getQuilometragemAtual());

        return veiculoRepository.save(veiculoExistente);
    }

    public void excluir(String placa) {
        veiculoRepository.deleteById(placa);
    }

    public Veiculo adicionarManutencao(String placa, Manutencao manutencao) {
        Optional<Veiculo> veiculoOptional = veiculoRepository.findById(placa);
        if (veiculoOptional.isEmpty()) {
            throw new RuntimeException("Veículo não encontrado");
        }

        Veiculo veiculo = veiculoOptional.get();

        int ultimaKm = veiculo.getManutencoes().stream()
                .mapToInt(Manutencao::getQuilometragem)
                .max()
                .orElse(0);

        if (manutencao.getQuilometragem() - ultimaKm >= 5000) {
            String assunto = "⚠️ Troca de óleo recomendada - Veículo " + veiculo.getModelo();
            String mensagem = "Olá mecânico,\n\n" +
                    "Foi registrada uma nova manutenção no veículo:\n\n" +
                    "- Modelo: " + veiculo.getModelo() +
                    "\n- Placa: " + veiculo.getPlaca() +
                    "\n- Quilometragem: " + manutencao.getQuilometragem() + " km" +
                    "\n\nA quilometragem aumentou mais de 5.000 km desde a última manutenção.\n" +
                    "É recomendada a troca de óleo.\n\nAtenciosamente,\nSistema Wheels";

            emailUtil.enviarEmail("cguilherme052@gmail.com", assunto, mensagem);
        }

        if (manutencao.getQuilometragem() > veiculo.getQuilometragemAtual()) {
            veiculo.setQuilometragemAtual(manutencao.getQuilometragem());
            veiculoRepository.save(veiculo);
        }

        manutencao.setVeiculo(veiculo);
        manutencaoRepository.save(manutencao);

        return veiculo;
    }
}
